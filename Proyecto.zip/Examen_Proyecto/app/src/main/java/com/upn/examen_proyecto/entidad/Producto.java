package com.upn.examen_proyecto.entidad;

public class Producto {
    private int nro_id;
    private String nombre;
    private String categoria;
    private double pre_compra;
    private double pre_venta;
    private int stock;

    public Producto(String nombre, String categoria, double pre_compra, double pre_venta, int stock) {
        this.nombre = nombre;
        this.categoria = categoria;
        this.pre_compra = pre_compra;
        this.pre_venta = pre_venta;
        this.stock = stock;
    }

    public Producto(int nro_id, String nombre, String categoria, double pre_compra, double pre_venta, int stock) {
        this.nro_id = nro_id;
        this.nombre = nombre;
        this.categoria = categoria;
        this.pre_compra = pre_compra;
        this.pre_venta = pre_venta;
        this.stock = stock;
    }

    public int getNro_id() {
        return nro_id;
    }
    public void setNro_id(int nro_id) {
        this.nro_id = nro_id;
    }
    public String getNombre() {
        return nombre;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    public String getCategoria() {
        return categoria;
    }
    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }
    public double getPre_compra() {
        return pre_compra;
    }
    public void setPre_compra(double pre_compra) {
        this.pre_compra = pre_compra;
    }
    public double getPre_venta() {
        return pre_venta;
    }
    public void setPre_venta(double pre_venta) {
        this.pre_venta = pre_venta;
    }
    public int getStock() {
        return stock;
    }
    public void setStock(int stock) {
        this.stock = stock;
    }
}

package com.upn.examen_proyecto;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.upn.examen_proyecto.entidad.Producto;
import com.upn.examen_proyecto.dao.ProductoDAO;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    FloatingActionButton btnButton1;
    RecyclerView recyclerProducto;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        asignarReferencias();
    }
    private void asignarReferencias(){
        btnButton1 = findViewById(R.id.btnButton1);
        btnButton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { //Al darle al boton "+" se cambia de activity
                Intent intent = new Intent(MainActivity.this,FormularioActivity.class);
                startActivity(intent);
            }
        });
        recyclerProducto = findViewById(R.id.recyclerProducto);
    }
    private void mostrarDatos(){
        List<Producto> listaProducto = new ArrayList<>();
        ProductoDAO productoDAO = new ProductoDAO(this);
        productoDAO.abridBD();
        listaProducto = productoDAO.findAllProducto();

        CustomAdapter adaptador = new CustomAdapter(this, listaProducto);
        recyclerProducto.setAdapter(adaptador);
        recyclerProducto.setLayoutManager(new LinearLayoutManager(this));
    }
}
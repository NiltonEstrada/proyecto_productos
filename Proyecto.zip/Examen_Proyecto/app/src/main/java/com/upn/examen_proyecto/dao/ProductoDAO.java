package com.upn.examen_proyecto.dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import com.upn.examen_proyecto.entidad.Producto;
import com.upn.examen_proyecto.util.ProductoBD;
import com.upn.examen_proyecto.util.Constantes;

import java.util.ArrayList;
import java.util.List;

public class ProductoDAO {
    private ProductoBD productoBD;
    private SQLiteDatabase db;
    private Context context;

    public ProductoDAO(Context context){
        productoBD = new ProductoBD(context);
        this.context = context;
    }
    public void abridBD(){
        db = productoBD.getWritableDatabase();
    }
    public String registrarProducto(Producto producto){
        String mensaje = "";
        try{
            ContentValues valores = new ContentValues();
            valores.put("nombre",producto.getNombre());
            valores.put("categoria",producto.getCategoria());
            valores.put("precio compra",producto.getPre_compra());
            valores.put("precio venta",producto.getPre_venta());
            valores.put("stock",producto.getStock());
            long resultado = db.insert(Constantes.NOMBRE_TABLA,null,valores);
            if(resultado == -1){
                mensaje = "Producto no Registrado";
            }else{
                mensaje = "Producto Registrado correctamente";
            }
        }catch (Exception e){
            mensaje = e.getMessage();
        }
        return mensaje;
    }
    public String editarProducto(Producto producto){
        String mensaje = "";
        try{
            ContentValues valores = new ContentValues();
            valores.put("nombre",producto.getNombre());
            valores.put("categoria",producto.getCategoria());
            valores.put("precio compra",producto.getPre_compra());
            valores.put("precio venta",producto.getPre_venta());
            valores.put("stock",producto.getStock());
            long resultado = db.update(Constantes.NOMBRE_TABLA,valores,"nro_id="+producto.getNro_id(),null);
            if(resultado == -1){
                mensaje = "Error al editar";
            }else{
                mensaje = "Se editó exitosamente";
            }

        }catch (Exception e){
            mensaje = e.getMessage();
        }
        return mensaje;
    }

    public List<Producto> findAllProducto(){
        List<Producto> listaProductos = new ArrayList<>();
        try{
            Cursor c = db.rawQuery("SELECT * FROM "+Constantes.NOMBRE_TABLA,null);
            while(c.moveToNext()){
                listaProductos.add(new Producto( //Posision de las columnas de las tablas
                        c.getInt(0),
                        c.getString(1),
                        c.getString(2),
                        c.getDouble(3),
                        c.getDouble(4),
                        c.getInt(5)
                ));
            }
        }catch(Exception e){
            Log.d("=>",e.getMessage());
        }
        return  listaProductos;
    }
    public String eliminarProducto(int nro_id){
        String mensaje = "";
        try{
            long resultado = db.delete(Constantes.NOMBRE_TABLA,"nro_id="+nro_id,null);
            if (resultado == -1){
                mensaje = "Hubo un error al eliminar el registro del producto";
            }else{
                mensaje = "Se elimino el registro del producto exitosamente";
            }
        }catch (Exception e){
            mensaje = e.getMessage();
        }
        return mensaje;
    }
}

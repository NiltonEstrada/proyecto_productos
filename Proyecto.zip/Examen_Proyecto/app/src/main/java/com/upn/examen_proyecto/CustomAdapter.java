package com.upn.examen_proyecto;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.upn.examen_proyecto.dao.ProductoDAO;
import com.upn.examen_proyecto.entidad.Producto;

import java.util.ArrayList;
import java.util.List;

public class CustomAdapter extends RecyclerView.Adapter<CustomAdapter.MyViewHolder> {
    private Context context;
    private List<Producto> listaProducto = new ArrayList<>();
    public CustomAdapter(Context context, List<Producto> listaProducto){
        this.context = context;
        this.listaProducto = listaProducto;
    }

    @NonNull
    @Override
    public CustomAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View vista = inflater.inflate(R.layout.fila,parent,false);
        return new MyViewHolder(vista);
    }

    @Override
    public void onBindViewHolder(@NonNull CustomAdapter.MyViewHolder holder, int position) {
        holder.fila_nombre.setText(listaProducto.get(position).getNombre()+"");
        holder.fila_categoria.setText(listaProducto.get(position).getCategoria()+"");
        holder.fila_pre_venta.setText(listaProducto.get(position).getPre_venta()+"");
        holder.fila_pre_compra.setText(listaProducto.get(position).getPre_compra()+"");
        holder.fila_stock.setText(listaProducto.get(position).getStock()+"");

        holder.btnEditar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { //Llama toda la info de estudiante y lo pone en el FormularioEstudiante
                Intent intent = new Intent(context,FormularioActivity.class);
                intent.putExtra("var_nro_id", listaProducto.get(position).getNro_id());
                intent.putExtra("var_nombre", listaProducto.get(position).getNombre());
                intent.putExtra("var_categoria", listaProducto.get(position).getCategoria());
                intent.putExtra("var_pre_venta", listaProducto.get(position).getPre_venta());
                intent.putExtra("var_pre_compra", listaProducto.get(position).getPre_compra());
                intent.putExtra("var_stock", listaProducto.get(position).getStock());
                context.startActivity(intent);

            }
        });

        holder.btnEliminar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder ventana = new AlertDialog.Builder(context);
                ventana.setTitle("Eliminar");
                ventana.setMessage("¿Desea eliminar el registro del producto: "+listaProducto.get(position).getNombre()+"?");
                ventana.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        ProductoDAO productoDAO = new ProductoDAO(context);
                        productoDAO.abridBD();
                        String mensaje = productoDAO.eliminarProducto(listaProducto.get(position).getNro_id());
                        AlertDialog.Builder v = new AlertDialog.Builder(context);
                        v.setTitle("Sub-Aviso");
                        v.setMessage(mensaje);
                        v.setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                Intent intent = new Intent(context, MainActivity.class);
                                context.startActivity(intent);
                            }
                        });
                        v.create().show();
                    }
                });
                ventana.setNegativeButton("Cancel",null);
                ventana.create().show();
            }
        });
    }

    @Override
    public int getItemCount() {
        return 0;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView fila_nombre, fila_categoria, fila_pre_venta, fila_pre_compra, fila_stock;
        ImageButton btnEditar, btnEliminar;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            fila_nombre = itemView.findViewById(R.id.fila_nombre);
            fila_categoria = itemView.findViewById(R.id.fila_categoria);
            fila_pre_venta = itemView.findViewById(R.id.fila_pre_venta);
            fila_pre_compra = itemView.findViewById(R.id.fila_pre_compra);
            fila_stock = itemView.findViewById(R.id.fila_stock);

            btnEliminar = itemView.findViewById(R.id.btnEliminar);
            btnEditar = itemView.findViewById(R.id.btnEditar);
        }
    }
}

package com.upn.examen_proyecto;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.upn.examen_proyecto.dao.ProductoDAO;
import com.upn.examen_proyecto.entidad.Producto;

public class FormularioActivity extends AppCompatActivity {
    EditText txtNombre, txtPre_Com, txtPre_Ven, txtStock;
    Spinner spiCategoria;
    Button btnProducto;

    Boolean registra = true;

    String nombre, categoria;
    int nro_id, stock;
    Double pre_venta, pre_compra;

    TextView txtTitulo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_formulario);

        asignarReferencias();
    }
    private void asignarReferencias(){
        txtNombre = findViewById(R.id.txtNombre);
        spiCategoria=findViewById(R.id.spiCategoria);
        txtPre_Com = findViewById(R.id.txtPre_Com);
        txtPre_Ven = findViewById(R.id.txtPre_Ven);
        txtStock = findViewById(R.id.txtStock);


        String[] categorias={"Tipo de categoria","A","B","C","D"};
        ArrayAdapter<String> adapter=new ArrayAdapter<String>
                (this,android.R.layout.simple_spinner_item,categorias);
        spiCategoria.setAdapter(adapter);

        btnProducto = findViewById(R.id.btnProducto);
        btnProducto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                RegistrarProducto();
                RecibirDatos();
            }
        });
    }
    private void RegistrarProducto() {
        String nombre, categoria;
        double pre_com, pre_ven;
        int stock;

        nombre = txtNombre.getText().toString();
        categoria = spiCategoria.getSelectedItem().toString();
        pre_com = Double.parseDouble(txtPre_Com.getText().toString());
        pre_ven = Double.parseDouble(txtPre_Ven.getText().toString());
        stock = Integer.parseInt(txtStock.getText().toString());

        ProductoDAO productoDAO = new ProductoDAO(this);
        productoDAO.abridBD();

        String mensaje;
        if(registra == true){
            Producto producto = new Producto(nombre, categoria, pre_com, pre_ven, stock);
            mensaje = productoDAO.registrarProducto(producto);
        }else{
            Producto producto = new Producto(nro_id, nombre, categoria, pre_com, pre_ven, stock);
            mensaje = productoDAO.editarProducto(producto);
        }

        AlertDialog.Builder ventana = new AlertDialog.Builder(FormularioActivity.this);
        ventana.setTitle("Aviso");
        ventana.setMessage(mensaje);
        ventana.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Intent intent = new Intent(FormularioActivity.this,MainActivity.class);
                startActivity(intent);
            }
        });
        ventana.create().show();

    }

    private void RecibirDatos(){
        if(getIntent().hasExtra("var_nro_id")){
            registra = false;
            nro_id = getIntent().getIntExtra("var_nro_id",0);
            nombre = getIntent().getStringExtra("var_nombre");
            categoria = getIntent().getStringExtra("var_categoria");
            pre_compra = getIntent().getDoubleExtra("var_pre_venta",0);
            pre_venta = getIntent().getDoubleExtra("var_pre_compra",0);
            stock = getIntent().getIntExtra("var_stock",0);

            txtNombre.setText(nombre);
            //spiCategoria.setAdapter(); //aqui si no se que se ponia
            txtPre_Com.setText(pre_compra+"");
            txtPre_Ven.setText(pre_venta+"");
            txtStock.setText(stock+"");
            txtTitulo.setText("Editar Producto");
            btnProducto.setText("Modificar Producto");
        }
    }
}
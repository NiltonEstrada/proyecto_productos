package com.upn.examen_proyecto.util;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class ProductoBD extends SQLiteOpenHelper {
    public ProductoBD(Context context){
        super(context, Constantes.NOMBRE_BD,null,Constantes.VERSION); //Crea tablas
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        String query =
                "CREATE TABLE "+Constantes.NOMBRE_TABLA+
                        "(nro_id INTEGER PRIMARY KEY AUTOINCREMENT, "+
                        "nombres TEXT NOT NULL, "+
                        "categoria TEXT NOT NULL, "+
                        "pre_compra DOUBLE NOT NULL,"+
                        "pre_venta DOUBLE NOT NULL,"+
                        "stock INTEGER NOT NULL);";
        db.execSQL(query);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}

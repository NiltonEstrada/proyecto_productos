package com.upn.examen_proyecto.util;

public class Constantes {
    public static final String NOMBRE_BD = "tienda.db";
    public static final String NOMBRE_TABLA = "producto";
    public static final int VERSION = 1;
}
